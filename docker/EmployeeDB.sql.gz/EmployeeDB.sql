-- Adminer 4.8.1 PostgreSQL 14.2 (Debian 14.2-1.pgdg110+1) dump

\connect "EmployeeDB";

DROP TABLE IF EXISTS "Company";
DROP SEQUENCE IF EXISTS "Company_cid_seq";
CREATE SEQUENCE "Company_cid_seq" INCREMENT  MINVALUE  MAXVALUE  CACHE ;

CREATE TABLE "public"."Company" (
    "cid" integer DEFAULT nextval('"Company_cid_seq"') NOT NULL,
    "company_name" character(50),
    CONSTRAINT "Company_pkey" PRIMARY KEY ("cid")
) WITH (oids = false);

INSERT INTO "Company" ("cid", "company_name") VALUES
(1,	'SAP                                               '),
(2,	'Canonical                                         '),
(3,	'Nari solutions                                    '),
(4,	'Oracle                                            ');

DROP TABLE IF EXISTS "Employee";
DROP SEQUENCE IF EXISTS "Employee_eid_seq";
CREATE SEQUENCE "Employee_eid_seq" INCREMENT  MINVALUE  MAXVALUE  CACHE ;

CREATE TABLE "public"."Employee" (
    "eid" integer DEFAULT nextval('"Employee_eid_seq"') NOT NULL,
    "first_name" character(50),
    "last_name" character(50),
    "cid" integer,
    CONSTRAINT "Employee_pkey" PRIMARY KEY ("eid")
) WITH (oids = false);

INSERT INTO "Employee" ("eid", "first_name", "last_name", "cid") VALUES
(1,	'William                                           ',	'Rolland                                           ',	1),
(2,	'Daniel                                            ',	'Piere                                             ',	1),
(3,	'Sam                                               ',	'Phillips                                          ',	2),
(4,	'Terese                                            ',	'Nelson                                            ',	2),
(5,	'Herman                                            ',	'Treadway                                          ',	3),
(6,	'David                                             ',	'Wright                                            ',	3),
(7,	'Max                                               ',	'Mustermann                                        ',	3),
(10,	'Myrat                                             ',	'Altyyev                                           ',	3);

ALTER TABLE ONLY "public"."Employee" ADD CONSTRAINT "Employee_cid_fkey" FOREIGN KEY (cid) REFERENCES "Company"(cid) ON UPDATE CASCADE ON DELETE RESTRICT NOT DEFERRABLE;

-- 2022-03-15 13:37:29.927895+00
